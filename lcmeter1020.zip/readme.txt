
This is the assembler source code and the hex file for the lc-meter. The software is designed for the use of an 2x16 LCD display ( 2 lines with 16 symbols each). The calibration capacitor (C9+C10) has to be 1020 pF.

Das sind der Assembler-Code und das HEX-File f�r das LC-Meter. Die Software ist f�r ein 2x16-LCD-Display ausgelegt (2 Zeilen a 16 Zeichen. Der Kalibrierkondensator (C9+C10) hat 1020pF zu sein.

lcmeter1020.HEX
lcmeter1020.asm



It is possible to use a cheaper 1x16 display. But in this case you have to use the following version of the software.

Man kann auch ein 1x16 Display benutzen, dann sind aber die folgenden Files zu verwenden.

lcmeter1020_1.HEX
lcmeter1020_1.asm